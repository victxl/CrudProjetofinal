package com.victxl.siteDeVendas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiteDeVendasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteDeVendasApplication.class, args);
	}

}
