package com.victxl.siteDeVendas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiteDeVendasApplicationTests {

	@Test
	void contextLoads() {
	}

}
